﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Timers;

namespace ServiceTest
{
    class ReadApplication : ServiceBase
    {
        System.Timers.Timer timer = new System.Timers.Timer();
        public Thread worker = null;
        public ReadApplication()
        {
            ServiceName = "ReadApp";
        }
        protected override void OnStart(string[] args)
        {
            ThreadStart start = new ThreadStart(working);
            worker = new Thread(start);
            worker.Start();
        }

        public void working()
        {
            int sleep = 1;
            while (true)
            {
                try
                {
                    Thread.Sleep(sleep * 60 * 1000);
                    ProcessStartInfo info = new ProcessStartInfo(@"C:\ProgramData\Susil\Postman\Postman.exe");
                    info.UseShellExecute = false;
                    info.RedirectStandardError = true;
                    info.RedirectStandardInput = true;
                    info.RedirectStandardOutput = true;
                    info.CreateNoWindow = true;
                    info.ErrorDialog = false;
                    info.WindowStyle = ProcessWindowStyle.Hidden;

                    Process process = Process.Start(info);
                    WriteToFile("Exe executed succesifully" + DateTime.Now);
                }
                catch(Exception ex)
                {
                    WriteToFile("Exe not executed " + DateTime.Now + ex.Message);
                }
            }
        }
        public void OnDebug()
        {
            //OnStart(null);
            WriteToFile("Service is call at " + DateTime.Now);
        }
        protected override void OnStop()
        {
            if (worker != null && worker.IsAlive)
            {
                worker.Abort();
                WriteToFile("Service is stopped at " + DateTime.Now);
            }

        }

        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            WriteToFile("Service is recall at " + DateTime.Now);
        }
        public void WriteToFile(string Message)
        {
            //string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            string path = @"E:\" + "\\Logs";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string filepath = @"E:\" + "\\Logs\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') + ".txt";
            if (!File.Exists(filepath))
            {
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
        }
    }
}
